package com.studentportfolio.Student.Portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentPortfolioApplication.class, args);
	}

}
