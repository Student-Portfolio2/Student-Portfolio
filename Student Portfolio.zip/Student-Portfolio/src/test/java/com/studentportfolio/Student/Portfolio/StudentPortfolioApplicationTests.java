package com.studentportfolio.Student.Portfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
